/* 
  Claps hands to reveal that there's no JavaScript on me before leaving the table.
*/
