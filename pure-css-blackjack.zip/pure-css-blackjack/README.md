# Pure CSS Blackjack

A Pen created on CodePen.

Original URL: [https://codepen.io/kevinnewcombe/pen/JjbKpMG](https://codepen.io/kevinnewcombe/pen/JjbKpMG).

A pure CSS hand of Blackjack which uses animating/pausing @property values to generate a random-ish set of cards.